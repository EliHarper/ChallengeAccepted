export class Skill {
}
