export class Message {
}
