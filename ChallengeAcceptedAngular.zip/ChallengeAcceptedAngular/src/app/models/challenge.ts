export class Challenge {
}
