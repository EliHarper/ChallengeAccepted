import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fallback',
  templateUrl: './fallback.component.html',
  styleUrls: ['./fallback.component.css']
})
export class FallbackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
